package com.example.audioencryptionapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AudioEncryptionAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(AudioEncryptionAppApplication.class, args);
	}

}
