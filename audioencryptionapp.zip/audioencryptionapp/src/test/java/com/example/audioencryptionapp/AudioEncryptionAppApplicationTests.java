package com.example.audioencryptionapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AudioEncryptionAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
